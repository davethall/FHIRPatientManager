"""A flexible client for FHIR servers supporting the SMART on FHIR protocol"""

from .client import __version__
